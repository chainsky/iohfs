Contributing guidelines for this project are available at

http://www.gwtproject.org/makinggwtbetter.html

