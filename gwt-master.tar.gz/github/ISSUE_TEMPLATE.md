<!--
 Please make sure your issue can be reproduced in the latest version of GWT.
 If possible, test in latest beta or release candidate (RC) as well.
-->

**GWT version:** 
**Browser (with version):** 
**Operating System:** 

---

##### Description
<!-- Note: Please use gist.github.com for longer log output -->






##### Steps to reproduce
<!-- Note: You can also provide a link to a demo project that reproduces the issue -->






<!--
 The following sections are optional and should be deleted if not required.
 You can also add additional sections if you need to.
-->

##### Known workarounds






##### Links to further discussions





