!!! GWT DOES NOT ACCEPT PULL REQUESTS ON GITHUB !!!

Thank you for creating a patch for GWT. This project uses Gerrit
to sign CLAs (Contributor License Agreement) and to review
code contributions. For that reason we can not accept pull requests
on Github.


If you want your patch to be accepted please follow the instructions on

http://www.gwtproject.org/makinggwtbetter.html
